# NuvPrivacity — compilación AAB con GitHub Actions

El proyecto está preparado para compilar `com.nuvprivacity.app` con Android SDK 36, Java 17 y Gradle 8.13.

El workflow genera:

`app/build/outputs/bundle/release/app-release.aab`

y lo publica en GitHub Actions como artefacto `NuvPrivacity-release-AAB`.

## Antes de subir a Google Play

La configuración actual genera el AAB de release, pero **no contiene una firma de carga de Google Play**. Para una publicación real, usa la misma upload key que corresponda a la aplicación de Play Console y configura la firma de forma segura en GitHub Actions/Android Studio. No subas el `.jks` ni contraseñas al repositorio.

## Datos de la app

- Application ID: `com.nuvprivacity.app`
- Version name: `1.0.1`
- Version code: `2`
- Billing: `nuvprivacity_premium`
