# NuvPrivacity release rules
